using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

internal static class Program
{
  private static readonly Dictionary<string, string> MimeTypes =
    new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
      { ".css", "text/css; charset=utf-8" },
      { ".html", "text/html; charset=utf-8" },
      { ".js", "text/javascript; charset=utf-8" },
      { ".json", "application/json; charset=utf-8" },
      { ".svg", "image/svg+xml" },
      { ".txt", "text/plain; charset=utf-8" }
    };

  private static int Main(string[] args)
  {
    string rootPath = AppDomain.CurrentDomain.BaseDirectory;
    string indexPath = Path.Combine(rootPath, "index.html");
    int preferredPort = 4173;
    bool openBrowser = true;

    if (!File.Exists(indexPath))
    {
      Console.Error.WriteLine("index.html was not found next to Snake.exe.");
      Console.Error.WriteLine("Keep Snake.exe in the project root folder.");
      WaitBeforeExit();
      return 1;
    }

    ParseArguments(args, ref preferredPort, ref openBrowser);

    TcpListener listener;
    int port;

    if (!TryStartListener(preferredPort, out listener, out port))
    {
      Console.Error.WriteLine("Unable to start the local Snake server.");
      WaitBeforeExit();
      return 1;
    }

    CancellationTokenSource cancellation = new CancellationTokenSource();
    Console.CancelKeyPress += delegate(object sender, ConsoleCancelEventArgs eventArgs)
    {
      eventArgs.Cancel = true;
      cancellation.Cancel();

      try
      {
        listener.Stop();
      }
      catch
      {
      }
    };

    Task serverTask = Task.Factory.StartNew(
      delegate { AcceptLoop(listener, rootPath, cancellation.Token); },
      cancellation.Token,
      TaskCreationOptions.LongRunning,
      TaskScheduler.Default);

    string url = string.Format(CultureInfo.InvariantCulture, "http://localhost:{0}/", port);

    Console.WriteLine("Snake launcher");
    Console.WriteLine("Serving: " + rootPath);
    Console.WriteLine("URL: " + url);
    Console.WriteLine("Press Enter to stop the server.");

    if (openBrowser)
    {
      TryOpenBrowser(url);
    }

    Console.ReadLine();
    cancellation.Cancel();

    try
    {
      listener.Stop();
    }
    catch
    {
    }

    try
    {
      serverTask.Wait(2000);
    }
    catch
    {
    }

    listener.Server.Close();
    cancellation.Dispose();
    return 0;
  }

  private static void ParseArguments(string[] args, ref int preferredPort, ref bool openBrowser)
  {
    for (int index = 0; index < args.Length; index += 1)
    {
      string argument = args[index];

      if (string.Equals(argument, "--no-browser", StringComparison.OrdinalIgnoreCase))
      {
        openBrowser = false;
        continue;
      }

      if (
        string.Equals(argument, "--port", StringComparison.OrdinalIgnoreCase) &&
        index + 1 < args.Length
      )
      {
        int parsedPort;

        if (int.TryParse(args[index + 1], NumberStyles.Integer, CultureInfo.InvariantCulture, out parsedPort))
        {
          preferredPort = parsedPort;
          index += 1;
        }
      }
    }
  }

  private static bool TryStartListener(int preferredPort, out TcpListener listener, out int port)
  {
    int[] candidates = BuildPortCandidates(preferredPort);

    for (int index = 0; index < candidates.Length; index += 1)
    {
      port = candidates[index];
      listener = new TcpListener(IPAddress.Loopback, port);

      try
      {
        listener.Start();
        return true;
      }
      catch (SocketException)
      {
        listener.Server.Close();
      }
    }

    listener = null;
    port = 0;
    return false;
  }

  private static int[] BuildPortCandidates(int preferredPort)
  {
    List<int> ports = new List<int>();

    if (preferredPort > 0)
    {
      ports.Add(preferredPort);
    }

    for (int port = 4173; port <= 4183; port += 1)
    {
      if (!ports.Contains(port))
      {
        ports.Add(port);
      }
    }

    return ports.ToArray();
  }

  private static void AcceptLoop(TcpListener listener, string rootPath, CancellationToken cancellationToken)
  {
    while (!cancellationToken.IsCancellationRequested)
    {
      TcpClient client = null;

      try
      {
        client = listener.AcceptTcpClient();
        HandleClient(client, rootPath);
      }
      catch (SocketException)
      {
        if (cancellationToken.IsCancellationRequested)
        {
          break;
        }
      }
      catch (ObjectDisposedException)
      {
        if (cancellationToken.IsCancellationRequested)
        {
          break;
        }
      }
      finally
      {
        if (client != null)
        {
          client.Close();
        }
      }
    }
  }

  private static void HandleClient(TcpClient client, string rootPath)
  {
    NetworkStream stream = client.GetStream();
    StreamReader reader = null;

    try
    {
      reader = new StreamReader(stream, Encoding.ASCII, false, 1024, true);
      string requestLine = reader.ReadLine();

      if (string.IsNullOrWhiteSpace(requestLine))
      {
        return;
      }

      while (true)
      {
        string headerLine = reader.ReadLine();

        if (headerLine == null || headerLine.Length == 0)
        {
          break;
        }
      }

      string[] requestParts = requestLine.Split(' ');

      if (requestParts.Length < 2)
      {
        WriteResponse(stream, 400, "Bad Request", "Bad request", "text/plain; charset=utf-8", false);
        return;
      }

      string method = requestParts[0].ToUpperInvariant();
      bool headOnly = string.Equals(method, "HEAD", StringComparison.Ordinal);

      if (!string.Equals(method, "GET", StringComparison.Ordinal) && !headOnly)
      {
        WriteResponse(stream, 405, "Method Not Allowed", "Method not allowed", "text/plain; charset=utf-8", false);
        return;
      }

      string filePath = GetSafePath(rootPath, requestParts[1]);

      if (filePath == null || !File.Exists(filePath))
      {
        WriteResponse(stream, 404, "Not Found", "Not found", "text/plain; charset=utf-8", headOnly);
        return;
      }

      string extension = Path.GetExtension(filePath);
      string contentType;

      if (!MimeTypes.TryGetValue(extension, out contentType))
      {
        contentType = "application/octet-stream";
      }

      byte[] body = File.ReadAllBytes(filePath);
      WriteResponse(stream, 200, "OK", body, contentType, headOnly);
    }
    catch
    {
      try
      {
        WriteResponse(stream, 500, "Internal Server Error", "Internal server error", "text/plain; charset=utf-8", false);
      }
      catch
      {
      }
    }
    finally
    {
      if (reader != null)
      {
        reader.Dispose();
      }
    }
  }

  private static string GetSafePath(string rootPath, string requestTarget)
  {
    string pathOnly = requestTarget ?? "/";
    int queryIndex = pathOnly.IndexOf('?');

    if (queryIndex >= 0)
    {
      pathOnly = pathOnly.Substring(0, queryIndex);
    }

    string decodedPath = Uri.UnescapeDataString(pathOnly);

    if (decodedPath == "/" || decodedPath.Length == 0)
    {
      return Path.Combine(rootPath, "index.html");
    }

    string relativePath = decodedPath.Replace('/', Path.DirectorySeparatorChar).TrimStart(Path.DirectorySeparatorChar);
    string fullRootPath = Path.GetFullPath(rootPath);
    string fullCandidatePath = Path.GetFullPath(Path.Combine(fullRootPath, relativePath));
    string rootWithSeparator = fullRootPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;

    if (
      !string.Equals(fullCandidatePath, fullRootPath, StringComparison.OrdinalIgnoreCase) &&
      !fullCandidatePath.StartsWith(rootWithSeparator, StringComparison.OrdinalIgnoreCase)
    )
    {
      return null;
    }

    if (Directory.Exists(fullCandidatePath))
    {
      string directoryIndex = Path.Combine(fullCandidatePath, "index.html");

      if (File.Exists(directoryIndex))
      {
        return directoryIndex;
      }
    }

    return fullCandidatePath;
  }

  private static void WriteResponse(
    NetworkStream stream,
    int statusCode,
    string statusText,
    string body,
    string contentType,
    bool headOnly
  )
  {
    byte[] bytes = Encoding.UTF8.GetBytes(body ?? string.Empty);
    WriteResponse(stream, statusCode, statusText, bytes, contentType, headOnly);
  }

  private static void WriteResponse(
    NetworkStream stream,
    int statusCode,
    string statusText,
    byte[] body,
    string contentType,
    bool headOnly
  )
  {
    if (body == null)
    {
      body = new byte[0];
    }

    string headers = string.Format(
      CultureInfo.InvariantCulture,
      "HTTP/1.1 {0} {1}\r\nContent-Type: {2}\r\nContent-Length: {3}\r\nConnection: close\r\n\r\n",
      statusCode,
      statusText,
      contentType,
      body.Length);
    byte[] headerBytes = Encoding.ASCII.GetBytes(headers);
    stream.Write(headerBytes, 0, headerBytes.Length);

    if (!headOnly && body.Length > 0)
    {
      stream.Write(body, 0, body.Length);
    }

    stream.Flush();
  }

  private static void TryOpenBrowser(string url)
  {
    try
    {
      Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
    }
    catch
    {
      Console.WriteLine("Open the URL manually if the browser does not launch.");
    }
  }

  private static void WaitBeforeExit()
  {
    Console.WriteLine("Press Enter to close.");
    Console.ReadLine();
  }
}
