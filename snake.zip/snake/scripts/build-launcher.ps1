param(
  [string]$OutputPath = (Join-Path (Split-Path -Parent $PSScriptRoot) "Snake.exe")
)

$ErrorActionPreference = "Stop"
$scriptPath = Join-Path $PSScriptRoot "SnakeLauncher.cs"
$compilerPath = "C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"

if (-not (Test-Path $scriptPath -PathType Leaf)) {
  throw "Missing source file: $scriptPath"
}

if (-not (Test-Path $compilerPath -PathType Leaf)) {
  throw "C# compiler not found at $compilerPath"
}

& $compilerPath /nologo /target:exe /out:$OutputPath $scriptPath

if ($LASTEXITCODE -ne 0) {
  throw "Launcher build failed."
}

Write-Host "Built launcher: $OutputPath"
