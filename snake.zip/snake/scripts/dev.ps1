param(
  [int]$Port = 4173
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)

$mimeTypes = @{
  ".css" = "text/css; charset=utf-8"
  ".html" = "text/html; charset=utf-8"
  ".js" = "text/javascript; charset=utf-8"
  ".json" = "application/json; charset=utf-8"
  ".svg" = "image/svg+xml"
  ".txt" = "text/plain; charset=utf-8"
}

function Get-SafePath([string]$RequestPath) {
  $trimmed = $RequestPath.TrimStart("/")

  if ([string]::IsNullOrWhiteSpace($trimmed)) {
    return Join-Path $root "index.html"
  }

  $segments = $trimmed -split "[\\/]+" | Where-Object {
    $_ -and $_ -ne "." -and $_ -ne ".."
  }

  if ($segments.Count -eq 0) {
    return Join-Path $root "index.html"
  }

  $resolvedPath = $root

  foreach ($segment in $segments) {
    $resolvedPath = Join-Path $resolvedPath $segment
  }

  return $resolvedPath
}

$listener.Start()

function Write-Response(
  [System.IO.Stream]$Stream,
  [int]$StatusCode,
  [string]$StatusText,
  [byte[]]$Body,
  [string]$ContentType,
  [bool]$HeadOnly
) {
  if ($null -eq $Body) {
    $Body = [byte[]]@()
  }

  $headers = @(
    "HTTP/1.1 $StatusCode $StatusText",
    "Content-Type: $ContentType",
    "Content-Length: $($Body.Length)",
    "Connection: close",
    "",
    ""
  )
  $headerBytes = [System.Text.Encoding]::ASCII.GetBytes(($headers -join "`r`n"))
  $Stream.Write($headerBytes, 0, $headerBytes.Length)

  if (-not $HeadOnly -and $Body.Length -gt 0) {
    $Stream.Write($Body, 0, $Body.Length)
  }

  $Stream.Flush()
}

Write-Host "Serving $root at http://localhost:$Port/"
Write-Host "Press Ctrl+C to stop."

try {
  while ($true) {
    $client = $listener.AcceptTcpClient()

    try {
      $stream = $client.GetStream()
      $reader = [System.IO.StreamReader]::new(
        $stream,
        [System.Text.Encoding]::ASCII,
        $false,
        1024,
        $true
      )
      $requestLine = $reader.ReadLine()

      if ([string]::IsNullOrWhiteSpace($requestLine)) {
        continue
      }

      while ($true) {
        $line = $reader.ReadLine()

        if ($null -eq $line -or $line -eq "") {
          break
        }
      }

      $requestParts = $requestLine.Split(" ")

      if ($requestParts.Length -lt 2) {
        $badRequest = [System.Text.Encoding]::UTF8.GetBytes("Bad request")
        Write-Response $stream 400 "Bad Request" $badRequest "text/plain; charset=utf-8" $false
        continue
      }

      $method = $requestParts[0].ToUpperInvariant()
      $headOnly = $method -eq "HEAD"

      if ($method -ne "GET" -and -not $headOnly) {
        $notAllowed = [System.Text.Encoding]::UTF8.GetBytes("Method not allowed")
        Write-Response $stream 405 "Method Not Allowed" $notAllowed "text/plain; charset=utf-8" $false
        continue
      }

      $pathOnly = $requestParts[1].Split("?")[0]
      $requestedPath = [System.Uri]::UnescapeDataString($pathOnly)
      $filePath = Get-SafePath $requestedPath

      if ((Test-Path $filePath -PathType Container) -and (Test-Path (Join-Path $filePath "index.html") -PathType Leaf)) {
        $filePath = Join-Path $filePath "index.html"
      }

      if (-not (Test-Path $filePath -PathType Leaf)) {
        $notFoundBytes = [System.Text.Encoding]::UTF8.GetBytes("Not found")
        Write-Response $stream 404 "Not Found" $notFoundBytes "text/plain; charset=utf-8" $headOnly
        continue
      }

      $extension = [System.IO.Path]::GetExtension($filePath).ToLowerInvariant()

      if ($mimeTypes.ContainsKey($extension)) {
        $contentType = $mimeTypes[$extension]
      } else {
        $contentType = "application/octet-stream"
      }

      $bytes = [System.IO.File]::ReadAllBytes($filePath)
      Write-Response $stream 200 "OK" $bytes $contentType $headOnly
    } catch {
      $stream = $client.GetStream()
      $errorBytes = [System.Text.Encoding]::UTF8.GetBytes("Internal server error")
      Write-Response $stream 500 "Internal Server Error" $errorBytes "text/plain; charset=utf-8" $false
    } finally {
      if ($null -ne $reader) {
        $reader.Dispose()
      }

      $client.Dispose()
    }
  }
} finally {
  $listener.Stop()
}
