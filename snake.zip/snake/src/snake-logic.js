(function (global) {
  const BOARD_SIZE = 16;
  const TICK_MS = 140;
  const MAX_DIRECTION_QUEUE = 2;
  const INITIAL_DIRECTION = "right";

  const DIRECTIONS = {
    up: { x: 0, y: -1 },
    down: { x: 0, y: 1 },
    left: { x: -1, y: 0 },
    right: { x: 1, y: 0 }
  };

  const OPPOSITES = {
    up: "down",
    down: "up",
    left: "right",
    right: "left"
  };

  function makePoint(x, y) {
    return { x: x, y: y };
  }

  function clonePoint(point) {
    return makePoint(point.x, point.y);
  }

  function cloneSnake(snake) {
    return snake.map(clonePoint);
  }

  function samePoint(a, b) {
    return a.x === b.x && a.y === b.y;
  }

  function pointKey(point) {
    return point.x + ":" + point.y;
  }

  function normalizeRandom(value) {
    if (typeof value !== "number" || !isFinite(value)) {
      return 0;
    }

    if (value <= 0) {
      return 0;
    }

    if (value >= 1) {
      return 0.999999999999;
    }

    return value;
  }

  function buildInitialSnake(boardSize) {
    const centerY = Math.floor(boardSize / 2);
    const headX = Math.floor(boardSize / 2);

    return [
      makePoint(headX, centerY),
      makePoint(headX - 1, centerY),
      makePoint(headX - 2, centerY)
    ];
  }

  function listOpenCells(boardSize, snake) {
    const occupied = new Set();
    const openCells = [];

    for (let index = 0; index < snake.length; index += 1) {
      occupied.add(pointKey(snake[index]));
    }

    for (let y = 0; y < boardSize; y += 1) {
      for (let x = 0; x < boardSize; x += 1) {
        const cell = makePoint(x, y);

        if (!occupied.has(pointKey(cell))) {
          openCells.push(cell);
        }
      }
    }

    return openCells;
  }

  function placeFood(boardSize, snake, randomFn) {
    const openCells = listOpenCells(boardSize, snake);

    if (openCells.length === 0) {
      return null;
    }

    const randomValue = normalizeRandom((randomFn || Math.random)());
    const index = Math.floor(randomValue * openCells.length);

    return clonePoint(openCells[index]);
  }

  function createInitialState(options) {
    const settings = options || {};
    const boardSize = settings.boardSize || BOARD_SIZE;
    const snake = buildInitialSnake(boardSize);

    return {
      boardSize: boardSize,
      snake: snake,
      direction: INITIAL_DIRECTION,
      directionQueue: [],
      food: placeFood(boardSize, snake, settings.randomFn),
      score: 0,
      status: "ready",
      reason: null
    };
  }

  function startGame(state) {
    if (state.status === "ready" || state.status === "paused") {
      return Object.assign({}, state, { status: "running" });
    }

    return state;
  }

  function togglePause(state) {
    if (state.status === "running") {
      return Object.assign({}, state, { status: "paused" });
    }

    if (state.status === "paused") {
      return Object.assign({}, state, { status: "running" });
    }

    return state;
  }

  function restartGame(state, randomFn) {
    return createInitialState({
      boardSize: state.boardSize,
      randomFn: randomFn
    });
  }

  function queueDirection(state, nextDirection) {
    if (!DIRECTIONS[nextDirection]) {
      return state;
    }

    if (state.status === "gameover") {
      return state;
    }

    const nextQueue = Array.isArray(state.directionQueue)
      ? state.directionQueue.slice(0, MAX_DIRECTION_QUEUE)
      : [];
    let referenceDirection = state.direction;

    for (let index = 0; index < nextQueue.length; index += 1) {
      referenceDirection = nextQueue[index];
    }

    if (referenceDirection === nextDirection) {
      return state;
    }

    if (OPPOSITES[referenceDirection] === nextDirection) {
      return state;
    }

    if (nextQueue.length >= MAX_DIRECTION_QUEUE) {
      return state;
    }

    nextQueue.push(nextDirection);

    return Object.assign({}, state, { directionQueue: nextQueue });
  }

  function advanceGame(state, randomFn) {
    if (state.status !== "running") {
      return state;
    }

    const directionQueue = Array.isArray(state.directionQueue)
      ? state.directionQueue.slice(0, MAX_DIRECTION_QUEUE)
      : [];
    const nextDirection = directionQueue.length > 0
      ? directionQueue.shift()
      : state.direction;
    const movement = DIRECTIONS[nextDirection];
    const nextHead = makePoint(
      state.snake[0].x + movement.x,
      state.snake[0].y + movement.y
    );
    const hitsWall = (
      nextHead.x < 0 ||
      nextHead.y < 0 ||
      nextHead.x >= state.boardSize ||
      nextHead.y >= state.boardSize
    );

    if (hitsWall) {
      return Object.assign({}, state, {
        direction: nextDirection,
        directionQueue: [],
        status: "gameover",
        reason: "wall"
      });
    }

    const grows = state.food !== null && samePoint(nextHead, state.food);
    const bodyToCheck = grows ? state.snake : state.snake.slice(0, -1);
    const hitsSelf = bodyToCheck.some(function (segment) {
      return samePoint(segment, nextHead);
    });

    if (hitsSelf) {
      return Object.assign({}, state, {
        direction: nextDirection,
        directionQueue: [],
        status: "gameover",
        reason: "self"
      });
    }

    const nextSnake = [nextHead].concat(cloneSnake(state.snake));

    if (!grows) {
      nextSnake.pop();
    }

    let nextFood = state.food ? clonePoint(state.food) : null;
    let nextStatus = state.status;
    let nextReason = null;

    if (grows) {
      nextFood = placeFood(state.boardSize, nextSnake, randomFn);

      if (nextFood === null) {
        nextStatus = "gameover";
        nextReason = "cleared";
      }
    }

    return {
      boardSize: state.boardSize,
      snake: nextSnake,
      direction: nextDirection,
      directionQueue: directionQueue,
      food: nextFood,
      score: state.score + (grows ? 1 : 0),
      status: nextStatus,
      reason: nextReason
    };
  }

  global.SnakeLogic = {
    BOARD_SIZE: BOARD_SIZE,
    TICK_MS: TICK_MS,
    MAX_DIRECTION_QUEUE: MAX_DIRECTION_QUEUE,
    DIRECTIONS: DIRECTIONS,
    createInitialState: createInitialState,
    startGame: startGame,
    togglePause: togglePause,
    restartGame: restartGame,
    queueDirection: queueDirection,
    advanceGame: advanceGame,
    placeFood: placeFood,
    samePoint: samePoint
  };
}(typeof window !== "undefined" ? window : globalThis));
