(function () {
  const logic = window.SnakeLogic;
  const SNAP_ALPHA_IDLE = 1;
  const boardElement = document.getElementById("board");
  const scoreElement = document.getElementById("score");
  const statusElement = document.getElementById("status");
  const startButton = document.getElementById("start-button");
  const restartButton = document.getElementById("restart-button");
  const touchButtons = document.querySelectorAll("[data-direction]");
  const directionKeys = {
    arrowup: "up",
    w: "up",
    "\u0446": "up",
    arrowdown: "down",
    s: "down",
    "\u044b": "down",
    arrowleft: "left",
    a: "left",
    "\u0444": "left",
    arrowright: "right",
    d: "right",
    "\u0432": "right"
  };
  const directionCodes = {
    KeyW: "up",
    KeyS: "down",
    KeyA: "left",
    KeyD: "right"
  };

  let state = logic.createInitialState();
  let previousSnapshot = createSnapshot(state);
  let currentSnapshot = createSnapshot(state);
  let boardGridElement = null;
  let pieceLayerElement = null;
  let foodElement = null;
  let segmentElements = [];
  let boardMetrics = {
    cellSize: 0,
    gap: 0
  };
  let accumulator = 0;
  let lastFrameTime = 0;

  function clonePoint(point) {
    return { x: point.x, y: point.y };
  }

  function createSnapshot(sourceState) {
    return {
      boardSize: sourceState.boardSize,
      snake: sourceState.snake.map(clonePoint),
      food: sourceState.food ? clonePoint(sourceState.food) : null,
      score: sourceState.score,
      status: sourceState.status,
      reason: sourceState.reason
    };
  }

  function buildBoard(boardSize) {
    const grid = document.createElement("div");
    const layer = document.createElement("div");
    const food = document.createElement("div");
    const fragment = document.createDocumentFragment();

    grid.className = "board-grid";
    layer.className = "piece-layer";
    food.className = "food-sprite";
    food.setAttribute("aria-hidden", "true");
    layer.appendChild(food);

    segmentElements = [];
    boardElement.style.setProperty("--board-size", String(boardSize));
    boardElement.replaceChildren();
    boardElement.appendChild(grid);
    boardElement.appendChild(layer);
    boardGridElement = grid;
    pieceLayerElement = layer;
    foodElement = food;

    for (let y = 0; y < boardSize; y += 1) {
      for (let x = 0; x < boardSize; x += 1) {
        const cell = document.createElement("div");
        cell.className = "cell";
        cell.setAttribute("role", "gridcell");
        fragment.appendChild(cell);
      }
    }

    boardGridElement.appendChild(fragment);
    updateBoardMetrics();
  }

  function updateBoardMetrics() {
    if (!pieceLayerElement) {
      return;
    }

    const boardStyles = window.getComputedStyle(boardElement);
    const gap = parseFloat(boardStyles.getPropertyValue("--cell-gap")) || 0;
    const width = pieceLayerElement.clientWidth;
    const cellSize = Math.max(0, (width - (gap * (state.boardSize - 1))) / state.boardSize);

    boardMetrics = {
      cellSize: cellSize,
      gap: gap
    };

    pieceLayerElement.style.setProperty("--segment-size", cellSize + "px");
  }

  function getRenderAlpha() {
    if (state.status !== "running") {
      return SNAP_ALPHA_IDLE;
    }

    return Math.min(accumulator / logic.TICK_MS, 1);
  }

  function resetSnapshots(sourceState) {
    previousSnapshot = createSnapshot(sourceState);
    currentSnapshot = createSnapshot(sourceState);
  }

  function resetLoopTiming() {
    accumulator = 0;
    lastFrameTime = performance.now();
  }

  function getInterpolatedPoint(previousPoint, currentPoint, alpha) {
    return {
      x: previousPoint.x + ((currentPoint.x - previousPoint.x) * alpha),
      y: previousPoint.y + ((currentPoint.y - previousPoint.y) * alpha)
    };
  }

  function toPixelPosition(point) {
    const step = boardMetrics.cellSize + boardMetrics.gap;

    return {
      x: point.x * step,
      y: point.y * step
    };
  }

  function applyPiecePosition(element, point) {
    const position = toPixelPosition(point);
    const size = boardMetrics.cellSize;

    element.style.width = size + "px";
    element.style.height = size + "px";
    element.style.transform = "translate3d(" + position.x + "px, " + position.y + "px, 0)";
  }

  function ensureSegmentElements(count) {
    while (segmentElements.length < count) {
      const segment = document.createElement("div");
      segment.className = "snake-segment";
      segment.setAttribute("aria-hidden", "true");
      pieceLayerElement.appendChild(segment);
      segmentElements.push(segment);
    }

    while (segmentElements.length > count) {
      const segment = segmentElements.pop();
      segment.remove();
    }
  }

  function getStatusMessage(currentState) {
    if (currentState.status === "ready") {
      return "Press Start or use Arrows, WASD, or \u0426\u0424\u042b\u0412 to begin.";
    }

    if (currentState.status === "paused") {
      return "Paused. Press Space or Resume when you are ready.";
    }

    if (currentState.status === "gameover") {
      if (currentState.reason === "cleared") {
        return "Board cleared. Press Restart to play again.";
      }

      return "Game over. Press Restart to try again.";
    }

    return "Use Arrows, WASD, or \u0426\u0424\u042b\u0412 to steer.";
  }

  function getStartLabel(currentState) {
    if (currentState.status === "running") {
      return "Pause";
    }

    if (currentState.status === "paused") {
      return "Resume";
    }

    if (currentState.status === "gameover") {
      return "Play Again";
    }

    return "Start";
  }

  function renderPieces(alpha) {
    const currentSnake = currentSnapshot.snake;
    const previousSnake = previousSnapshot.snake;

    ensureSegmentElements(currentSnake.length);

    for (let index = 0; index < currentSnake.length; index += 1) {
      const segmentElement = segmentElements[index];
      const currentPoint = currentSnake[index];
      const previousIndex = Math.min(index, Math.max(previousSnake.length - 1, 0));
      const previousPoint = previousSnake[previousIndex] || currentPoint;
      const renderPoint = alpha < 1
        ? getInterpolatedPoint(previousPoint, currentPoint, alpha)
        : currentPoint;

      segmentElement.classList.toggle("head", index === 0);
      segmentElement.style.zIndex = String(currentSnake.length - index);
      applyPiecePosition(segmentElement, renderPoint);
    }

    if (currentSnapshot.food) {
      foodElement.hidden = false;
      applyPiecePosition(foodElement, currentSnapshot.food);
    } else {
      foodElement.hidden = true;
    }
  }

  function render(alpha) {
    renderPieces(alpha);
    scoreElement.textContent = String(state.score);
    statusElement.textContent = getStatusMessage(state);
    startButton.textContent = getStartLabel(state);
    boardElement.dataset.state = state.status;
  }

  function restart(autoStart) {
    state = logic.restartGame(state, Math.random);
    resetSnapshots(state);
    resetLoopTiming();

    if (autoStart) {
      state = logic.startGame(state);
      resetSnapshots(state);
    }

    render(SNAP_ALPHA_IDLE);
  }

  function handleDirection(direction) {
    if (!direction || state.status === "gameover") {
      return;
    }

    if (state.status === "ready") {
      state = logic.startGame(state);
      resetSnapshots(state);
      resetLoopTiming();
    }

    state = logic.queueDirection(state, direction);
    render(getRenderAlpha());
  }

  function handleStartButton() {
    if (state.status === "gameover") {
      restart(true);
      return;
    }

    if (state.status === "ready") {
      state = logic.startGame(state);
      resetSnapshots(state);
      resetLoopTiming();
    } else {
      state = logic.togglePause(state);
      resetSnapshots(state);
      resetLoopTiming();
    }

    render(getRenderAlpha());
  }

  function getDirectionFromEvent(event) {
    if (directionCodes[event.code]) {
      return directionCodes[event.code];
    }

    return directionKeys[event.key.toLowerCase()];
  }

  function advanceFrame() {
    const nextState = logic.advanceGame(state, Math.random);

    if (nextState !== state) {
      previousSnapshot = createSnapshot(state);
      state = nextState;
      currentSnapshot = createSnapshot(state);
    }
  }

  document.addEventListener("keydown", function (event) {
    const key = event.key.toLowerCase();
    const direction = getDirectionFromEvent(event);

    if (direction) {
      event.preventDefault();
      handleDirection(direction);
      return;
    }

    if (key === " " || key === "spacebar") {
      event.preventDefault();
      handleStartButton();
      return;
    }

    if (key === "r") {
      event.preventDefault();
      restart(false);
    }
  });

  startButton.addEventListener("click", handleStartButton);
  restartButton.addEventListener("click", function () {
    restart(false);
  });

  touchButtons.forEach(function (button) {
    button.addEventListener("pointerdown", function (event) {
      event.preventDefault();
      handleDirection(button.dataset.direction);
    });
  });

  if (window.ResizeObserver) {
    const resizeObserver = new window.ResizeObserver(function () {
      updateBoardMetrics();
      render(getRenderAlpha());
    });
    resizeObserver.observe(boardElement);
  } else {
    window.addEventListener("resize", function () {
      updateBoardMetrics();
      render(getRenderAlpha());
    });
  }

  function runFrame(timestamp) {
    if (lastFrameTime === 0) {
      lastFrameTime = timestamp;
    }

    const delta = Math.min(timestamp - lastFrameTime, logic.TICK_MS * 3);
    lastFrameTime = timestamp;

    if (state.status === "running") {
      accumulator += delta;

      while (accumulator >= logic.TICK_MS && state.status === "running") {
        advanceFrame();
        accumulator -= logic.TICK_MS;
      }
    } else {
      accumulator = 0;
    }

    render(getRenderAlpha());
    window.requestAnimationFrame(runFrame);
  }

  buildBoard(state.boardSize);
  render(SNAP_ALPHA_IDLE);
  window.requestAnimationFrame(runFrame);
}());
